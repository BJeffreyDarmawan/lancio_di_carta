Please note that the normal map for the shelf "shelf_normal.bmp" 
and the specular map "shelf_specular" need to be set to tiling at 22x22 (u and v).

